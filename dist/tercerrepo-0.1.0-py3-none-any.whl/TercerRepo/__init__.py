def saludar(nombre):
    return f"Hola, {nombre}! Bienvenido a mi paquete de saludo."